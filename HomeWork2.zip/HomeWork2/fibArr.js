function fibArr(number){

    let a = [];
    if(number === 0)
    return a;

    if(number === 1)
    return a.push(1);

  for (let i = 2; i < number ; i++) {
      a[0]=1;
      a[1]=1;
      a.push(a[i-1]+a[i-2])
  }
    
   return a;
}
 

fibArr(3)