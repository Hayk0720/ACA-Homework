let arr = [5,4,78,0,-3,-7];
function findOddNumbers(arr){
    
    let arr1 = arr.filter(function(el){
    if(el%2 != 0)
     return 5;   
    
})
    
    let arr2 = arr1.map(function(el){
    
        return el=el*arr1.length;
})
    return arr2;
}

findOddNumbers(arr);