function sumOfDigits(number){
	let sum = 0
	function change(){
		 let str = number.toString();
		 str.split('');
		 for (let i = 0; i <str.length; i++) {
			  sum += parseInt(str[i])
		 }
		 return sum;
	}
	
	return sum;
}