function sumOfDigits(number){
   
        let sum = 0
        let sum1= 0;

        let str = number.toString();
        str.split('');
        for (let i = 0; i <str.length; i++) {
            sum += parseInt(str[i])
        }
       if(sum.toString().split('').length>1){
           let str1 = sum.toString();
           str1.split('');
           for (let i = 0; i <str1.length; i++) {
            sum1 += parseInt(str1[i])
        }
       } 
    
    
    return sum1;
}
sumOfDigits(999999999999)